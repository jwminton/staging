from dash.dependencies import Input, Output, State
from dash import Dash
from pandas import DataFrame
from pandas import read_pickle
from pandas_datareader import DataReader
from os import path
from datetime import datetime, timedelta
from dash_core_components import Graph, Dropdown
from dash_html_components import Div, Button
from plotly.offline import plot, get_plotlyjs

default_stock_list = [
    {'label': 'Tesla', 'value': 'TSLA'},
    {'label': 'Zoom', 'value': 'ZM'},
    {'label': 'Nvdia', 'value': 'NVDA'},
    {'label': 'Netflix', 'value': 'NFLX'},
]


def get_store_data(days=30, stock_list=default_stock_list):
    stock_data = {}
    for row in stock_list:
        ticker_label = row['label']
        ticker = row['value']
        stock_df = get_stock_data(days, ticker)
        stock_data[ticker] = {
            'symbol': ticker,
            'label': ticker_label,
            'index': stock_df.index,
            'High': stock_df.High,
            'Low': stock_df.Low,
            'Open': stock_df.Open,
            'Close': stock_df.Close,
            'Volume': stock_df.Volume,
            'trace': {
                'x': stock_df.index,
                'y': stock_df.Close,
                'name': ticker_label,
            }
        }
    return stock_data


def get_stock_data(days_ago, selected_value):
    cache_dir = 'dash_cache'
    cache_file_name = ''
    if path.exists(cache_dir):
        cache_file_name = f'{cache_dir}/{selected_value}_{days_ago}.pkl'
        try:
            ret_val = read_pickle(cache_file_name)
            print("cache hit:", cache_file_name)
            return ret_val
        except IOError:
            print('cache miss: ', cache_file_name)
            cache_file_name = ''

    print(f'Fetching {selected_value} data for {days_ago} days')
    ret_val = DataReader(
        selected_value,
        'yahoo',
        datetime.now() - timedelta(days=days_ago),
        datetime.now()
    )

    if path.exists(cache_dir):
        print(f'caching: {cache_file_name}')
        ret_val.to_pickle(cache_file_name)
    return ret_val


def base_figure():
    trace_array = []
    for stock in get_store_data().values():
        trace_array.append(stock['trace'])

    return {
        'data': trace_array,
        'layout': {
            'showlegend': True,
            'margin': {'r': 5, 't': 15},
        }
    }


aggregate_ops = [
    {'label': 'Max', 'value': 'max'},
    {'label': 'Median', 'value': 'median'},
    {'label': 'Average', 'value': 'mean'},
    {'label': 'Min', 'value': 'min'},
]


def stock_panel():
    operation_list = Dropdown(
        id='dropdown',
        options=aggregate_ops,
        clearable=True,
        style={'width': '175px'},
    )
    base_graph = Graph(id='graph',
                       figure=base_figure(),
                       # config={'displayModeBar': False},
                       )
    return Div([
        operation_list,
        base_graph,
    ], style={'width': '100%'})


app = Dash("Simple Stock View")
app.layout = Div([
    stock_panel(),
    Button(id='save', children='Save'),
])


@app.callback(Output('save', 'children'),
              Input('save', 'n_clicks'),
              State('graph', 'figure'),
              prevent_initial_call=True)
def save_graph(n_clicks, graph):
    # multiple div/graphs could be included as needed. Keep the plotlyjs separate
    # and only included once since it's 3MB (7 in development)
    div = plot(graph, output_type='div', include_plotlyjs=False)
    html = '''
    <html>
        <head>
            <script type="text/javascript">{plotlyjs}</script>
        </head>
        <body>
            <h1>Dash Example Save</h1>
           {div}
        </body>
    </html>
    '''.format(plotlyjs=get_plotlyjs(), div=div)
    with open('interactive_dash_save.html', 'w') as f:
        f.write(html)
    return 'saved'


@app.callback(Output('graph', 'figure'),
              [Input('dropdown', 'value'),
               Input('graph', 'restyleData')],
              State('graph', 'figure'),
              prevent_initial_call=True)
def computed_graph(selected_operation, rData, figure):
    trace_array = []
    for entry in figure['data']:
        if 'meta' not in entry:
            trace_array.append(entry)

    data_array = []
    for entry in trace_array:
        if 'visible' not in entry or entry['visible'] != 'legendonly':
            data_array.append(entry['y'])

    df = DataFrame(data_array)

    if selected_operation == 'median':
        sum_list = df.median(axis=0)
    elif selected_operation == 'mean':
        sum_list = df.mean(axis=0)
    elif selected_operation == 'min':
        sum_list = df.min(axis=0)
    elif selected_operation == 'max':
        sum_list = df.max(axis=0)
    else:
        sum_list = []

    if len(sum_list) > 0:
        trace_array.append({'x': trace_array[0]['x'],
                            'y': sum_list,
                            'name': selected_operation,
                            'line': {'color': 'purple'},
                            'meta': {'computed': True, }
                            })
    figure['data'] = trace_array
    return figure


if __name__ == '__main__':
    app.run_server(debug=True, port=8050)
