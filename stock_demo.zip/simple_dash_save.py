from dash.dependencies import Input, Output, State
from dash import Dash
from pandas import read_pickle
from pandas_datareader import DataReader
from os import path
from datetime import datetime, timedelta
from dash_core_components import Graph
from dash_html_components import Div, Button
from plotly.offline import plot, get_plotlyjs

default_stock_list = [
    {'label': 'Tesla', 'value': 'TSLA'},
    {'label': 'Zoom', 'value': 'ZM'},
    {'label': 'Nvdia', 'value': 'NVDA'},
    {'label': 'Netflix', 'value': 'NFLX'},
]


def get_store_data(days=30, stock_list=default_stock_list):
    stock_data = {}
    for row in stock_list:
        ticker_label = row['label']
        ticker = row['value']
        stock_df = get_stock_data(days, ticker)
        stock_data[ticker] = {
            'symbol': ticker,
            'label': ticker_label,
            'index': stock_df.index,
            'High': stock_df.High,
            'Low': stock_df.Low,
            'Open': stock_df.Open,
            'Close': stock_df.Close,
            'Volume': stock_df.Volume,
            'trace': {
                'x': stock_df.index,
                'y': stock_df.Close,
                'name': ticker_label,
            }
        }
    return stock_data


def get_stock_data(days_ago, selected_value):
    cache_dir = 'dash_cache'
    cache_file_name = ''
    if path.exists(cache_dir):
        cache_file_name = f'{cache_dir}/{selected_value}_{days_ago}.pkl'
        try:
            ret_val = read_pickle(cache_file_name)
            print("cache hit:", cache_file_name)
            return ret_val
        except IOError:
            print('cache miss: ', cache_file_name)
            cache_file_name = ''

    print(f'Fetching {selected_value} data for {days_ago} days')
    ret_val = DataReader(
        selected_value,
        'yahoo',
        datetime.now() - timedelta(days=days_ago),
        datetime.now()
    )

    if path.exists(cache_dir):
        print(f'caching: {cache_file_name}')
        ret_val.to_pickle(cache_file_name)
    return ret_val


def base_figure():
    trace_array = []
    for stock in get_store_data().values():
        trace_array.append(stock['trace'])

    return {
        'data': trace_array,
        'layout': {
            'showlegend': True,
            'margin': {'r': 5, 't': 15},
        }
    }


app = Dash("Simple Stock View")
app.layout = Div([
    Graph(id='graph', figure=base_figure()),
    Button(id='save', children='Save'),
])


@app.callback(Output('save', 'children'),
              Input('save', 'n_clicks'),
              State('graph', 'figure'),
              prevent_initial_call=True)
def save_graph(n_clicks, graph):
    html = '''
    <html>
        <head>
            <script type="text/javascript">{plotlyjs}</script>
        </head>
        <body>
            <h1>Dash Example Save</h1>
           {div}
        </body>
    </html>
    '''.format(plotlyjs=get_plotlyjs(),
               div=plot(graph, output_type='div', include_plotlyjs=False)
               )
    with open('simple_dash_save.html', 'w') as f:
        f.write(html)
    return 'Save'


if __name__ == '__main__':
    app.run_server(debug=True, port=8050)
