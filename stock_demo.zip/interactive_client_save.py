from dash.dependencies import Input, Output, State
from dash import Dash
from pandas import read_pickle
from pandas_datareader import DataReader
from os import path
from datetime import datetime, timedelta
from dash_core_components import Graph, Dropdown
from dash_html_components import Div

default_stock_list = [
    {'label': 'Tesla', 'value': 'TSLA'},
    {'label': 'Zoom', 'value': 'ZM'},
    {'label': 'Nvdia', 'value': 'NVDA'},
    {'label': 'Netflix', 'value': 'NFLX'},
]


def get_store_data(days=30, stock_list=default_stock_list):
    stock_data = {}
    for row in stock_list:
        ticker_label = row['label']
        ticker = row['value']
        stock_df = get_stock_data(days, ticker)
        stock_data[ticker] = {
            'symbol': ticker,
            'label': ticker_label,
            'index': stock_df.index,
            'High': stock_df.High,
            'Low': stock_df.Low,
            'Open': stock_df.Open,
            'Close': stock_df.Close,
            'Volume': stock_df.Volume,
            'trace': {
                'x': stock_df.index,
                'y': stock_df.Close,
                'name': ticker_label,
            }
        }
    return stock_data


def get_stock_data(days_ago, selected_value):
    cache_dir = 'dash_cache'
    if path.exists(cache_dir):
        cache_file_name = f'{cache_dir}/{selected_value}_{days_ago}.pkl'
        try:
            ret_val = read_pickle(cache_file_name)
            print("cache hit:", cache_file_name)
            return ret_val
        except IOError:
            print('cache miss: ', cache_file_name)

    print(f'Fetching {selected_value} data for {days_ago} days')
    ret_val = DataReader(
        selected_value,
        'yahoo',
        datetime.now() - timedelta(days=days_ago),
        datetime.now()
    )

    if path.exists(cache_dir):
        print(f'caching: {cache_file_name}')
        ret_val.to_pickle(cache_file_name)
    return ret_val


def base_figure():
    trace_array = []
    for stock in get_store_data().values():
        trace_array.append(stock['trace'])

    return {
        'data': trace_array,
        'layout': {
            'showlegend': True,
            'margin': {'r': 5, 't': 15},
        }
    }


default_stock_list = [
    {'label': 'Tesla', 'value': 'TSLA'},
    {'label': 'Zoom', 'value': 'ZM'},
    {'label': 'Nvdia', 'value': 'NVDA'},
    {'label': 'Netflix', 'value': 'NFLX'},
]

aggregate_ops = [
    {'label': 'Max', 'value': 'max'},
    {'label': 'Median', 'value': 'median'},
    {'label': 'Average', 'value': 'mean'},
    {'label': 'Min', 'value': 'min'},
]


def stock_graph():
    return Div([
        Dropdown(
            id='dropdown',
            options=aggregate_ops,
            clearable=True,
            style={'width': '175px'},
        ),
        Graph(id='graph',
              figure=base_figure(),
              config={'displayModeBar': False},
              ),
    ], style={'width': '100%'})


class MyDash(Dash):
    # initial layout and dependency script element
    def layout_script_elements(self):
        return '''<script id="_dash-layout" type="application/json">{auto_layout}</script>
                <script id="_dash-dependencies" type="application/json">{auto_deps}</script>'''.format(
            auto_layout=self.serve_layout().response[0].decode("utf-8"),
            auto_deps=self.dependencies().response[0].decode("utf-8"))

    # Called by Dash/Flask during startup for root page definition
    def interpolate_index(self, **kwargs):
        local_scripts = """<script src="/assets/ramda.min.js"></script>"""
        return '''<!DOCTYPE html>
        <html>
            <head>
                <title>Plotly/Dash Demo</title>
            </head>
            <body>   
             {app_entry}
                {config}
                {auto_layout}
                {local_scripts}
                {scripts}
                {renderer}
            </body>
        </html>'''.format(app_entry=kwargs.get('app_entry'),
                          auto_layout=self.layout_script_elements(),
                          config=kwargs.get('config'),
                          scripts=kwargs.get('scripts'),
                          local_scripts=local_scripts,
                          renderer=kwargs.get('renderer'),
                          )


app = MyDash("Simple Stock View")
app.layout = Div([
    stock_graph(),
])

app.clientside_callback(
    """
    function computed_graph(aggregateOp, rData, fig) {
            
        const traceArray = R.compose(
            R.reject(R.prop('meta')),
        )(fig.data)
        
        const dataArray = R.compose(
            R.map(R.prop('y')),
            R.reject(R.propEq('visible', 'legendonly')),
        )(traceArray)
        
        const transposedData = R.transpose(dataArray)
        var sum_list = null
        switch (aggregateOp) {
            case 'min':
                sum_list = R.map(R.reduce(R.min, Infinity))(transposedData)
                break 
            case 'max':
                sum_list = R.map(R.reduce(R.max, -Infinity))(transposedData)
                break 
            case 'median':
                sum_list = R.map(R.median)(transposedData)
                break
            case 'mean':
                sum_list = R.map(R.mean)(transposedData)
                break
        }
        if (sum_list != null)
            traceArray.push({
                x: fig.data[0].x ,
                y: sum_list,
                line: { color: 'purple' },
                name: aggregateOp,
                meta: { computed: true },
            })
        // clientside, this must be a deep copy to avoid object identity issues.  
        const newFig = JSON.parse(JSON.stringify(fig));
        newFig.data = traceArray
        return newFig
    }
    """,
    Output('graph', "figure"),
    [Input('dropdown', 'value'),
     Input('graph', "restyleData"),
     ],
    State('graph', "figure"),
    prevent_initial_call=True
)

if __name__ == '__main__':
    app.run_server(debug=False, port=8050)
