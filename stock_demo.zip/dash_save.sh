#/bin/bash
#
# Quick dumb script to capture/rewrite page to be local.
# The sed script rewrites '<script src' elements to be
# file local.
#
DEST_FILE="$$.file"

echo "save & process html file"
# This maps all src files locally to './lib' and recorrects the filename
if ( curl localhost:8050 | sed '/<script[ ]\+src\=/ {s#/_dash-component-suites/[^/]*/#./lib/#;s#/assets/#./lib/#;s#\.v[0-9m0-9_]*##;s#\?m=[0-9\.]*##}' > "$DEST_FILE" ); then
    SUCCESS=1
fi

if [ "$SUCCESS" ]; then
    echo "storing result as 'interactive_client_save.html'"
    mv "$DEST_FILE" interactive_client_save.html
    echo "success"
else
    echo "error getting page"
    rm  "$DEST_FILE"
    exit 1
fi
