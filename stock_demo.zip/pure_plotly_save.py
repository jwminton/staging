from plotly.graph_objects import Figure
from pandas import read_pickle
from pandas_datareader import DataReader
from os import path
from datetime import datetime, timedelta

default_stock_list = [
    {'label': 'Tesla', 'value': 'TSLA'},
    {'label': 'Zoom', 'value': 'ZM'},
    {'label': 'Nvdia', 'value': 'NVDA'},
    {'label': 'Netflix', 'value': 'NFLX'},
]


def get_store_data(days=30, stock_list=default_stock_list):
    stock_data = {}
    for row in stock_list:
        ticker_label = row['label']
        ticker = row['value']
        stock_df = get_stock_data(days, ticker)
        stock_data[ticker] = {
            'symbol': ticker,
            'label': ticker_label,
            'index': stock_df.index,
            'High': stock_df.High,
            'Low': stock_df.Low,
            'Open': stock_df.Open,
            'Close': stock_df.Close,
            'Volume': stock_df.Volume,
            'trace': {
                'x': stock_df.index,
                'y': stock_df.Close,
                'name': ticker_label,
            }
        }
    return stock_data


def get_stock_data(days_ago, selected_value):
    cache_dir = 'dash_cache'
    cache_file_name = ''
    if path.exists(cache_dir):
        cache_file_name = f'{cache_dir}/{selected_value}_{days_ago}.pkl'
        try:
            ret_val = read_pickle(cache_file_name)
            print("cache hit:", cache_file_name)
            return ret_val
        except IOError:
            print('cache miss: ', cache_file_name)
            cache_file_name = ''

    print(f'Fetching {selected_value} data for {days_ago} days')
    ret_val = DataReader(
        selected_value,
        'yahoo',
        datetime.now() - timedelta(days=days_ago),
        datetime.now()
    )

    if path.exists(cache_dir):
        print(f'caching: {cache_file_name}')
        ret_val.to_pickle(cache_file_name)
    return ret_val


def base_figure():
    trace_array = []
    for stock in get_store_data().values():
        trace_array.append(stock['trace'])

    return {
        'data': trace_array,
        'layout': {
            'showlegend': True,
            'margin': {'r': 5, 't': 15},
        }
    }

# Simple Pure Plotly graph save
fig = Figure(base_figure())
fig.write_html('pure_plotly_save.html', auto_open=False, include_plotlyjs=True)
