from pandas import read_pickle
from pandas_datareader import data as web
from os import path
from datetime import datetime
from datetime import timedelta
import dash
from dash.dependencies import Input, Output, State
import dash_core_components as dcc
import dash_html_components as html

# Quick command arg parsing. If we run on port 8888, the app will
# switch off debug mode so that a non-debug version of the page can be easily
# downloaded and processed to be a standalone page (script locations are
# rewritten to be local and assumed to be production minified versions)

# TODO: move sed/rewrite rules into the page generation logic itself
# Maybe try a Flask alternative app routing magic trick?
import argparse

parser = argparse.ArgumentParser()
# Cast input to integer, with a default value
parser.add_argument('-p', '--port', type=int, default=8050)
args = parser.parse_args()


class MyDash(dash.Dash):
    # CAVEAT: The initial_value logic is application specific by necessity for now.
    # HTML Snapshot initial layout and state script element generation
    def layout_script_elements(self):
        return '''<script id="_dash-layout" type="application/json">{auto_layout}</script>
                <script id="_dash-dependencies" type="application/json">{auto_deps}</script>'''.format(
            auto_layout=self.serve_layout().response[0].decode("utf-8"),
            auto_deps=self.dependencies().response[0].decode("utf-8"))

    def initial_values(self):
        return ""

    def getCss(self):
        return '''
<style>
* {
  box-sizing: border-box;
}
th, td {
  padding: 2px;
}
table {
  border: 1px solid black;
}
</style>'''

    def interpolate_index(self, **kwargs):
        # This might be nice to check for and throw and exception if missing
        # force ramda.min.js (NOTE: This autoloads Ramda into the window as R)
        local_scripts = """
                <script src="/static/ramda.min.js"></script>
                """

        return '''<!DOCTYPE html>
        <html>
            <head>
                {css}
                <title>Plotly/Dash Demo</title>
            </head>
            <body>   
             {app_entry}
                {config}
                {auto_layout}
                {initial_values}
                {local_scripts}
                {scripts}
                {renderer}
            </body>
        </html>'''.format(app_entry=kwargs.get('app_entry'),
                          auto_layout=self.layout_script_elements(),
                          initial_values=self.initial_values(),
                          config=kwargs.get('config'),
                          scripts=kwargs.get('scripts'),
                          local_scripts=local_scripts,
                          renderer=kwargs.get('renderer'),
                          css=self.getCss(),
                          )


# Normal stock data retrieval stuff from yahoo
def get_stock_data(days_ago, selected_value) -> object:
    if path.exists('dash_cache'):
        cache_file_name = f'dash_cache/{selected_value}_{abs(days_ago)}.pkl'
        try:
            ret_val = read_pickle(cache_file_name)
            print("cache hit:", cache_file_name)
            return ret_val
        except IOError:
            print('cache miss: ', cache_file_name)

    print(f'Fetching {selected_value} data for {abs(days_ago)} days')
    ret_val = web.DataReader(
        selected_value,
        'yahoo',
        datetime.now() - timedelta(days=abs(days_ago)),  # days_ago is negative
        datetime.now()
    )
    if path.exists('dash_cache'):
        print(f'caching: {cache_file_name}')
        ret_val.to_pickle(cache_file_name)

    return ret_val


def empty_graph():
    return {
        'data': [],
        'layout': {
            # 'paper_bgcolor': '#7f7f7f',
            'showlegend': True,
            'margin': {'l': 15, 'r': 5, 't': 15, 'b': 20},
            'yaxis': {'automargin': True},
            'xaxis': {'automargin': True},
        }
    }


# precanned stock choices
default_stock_list = [
    {'label': 'Amazon', 'value': 'AMZN'},
    {'label': 'Apple', 'value': 'AAPL'},
    {'label': 'Coke', 'value': 'COKE'},
    {'label': 'Facebook', 'value': 'FB'},
    {'label': 'Home Depot', 'value': 'HD'},
    {'label': 'Google', 'value': 'GOOG'},
    {'label': 'Microsoft', 'value': 'MSFT'},
    {'label': 'Netflix', 'value': 'NFLX'},
    {'label': 'Tesla', 'value': 'TSLA'},
    {'label': 'Twitter', 'value': 'TWTR'},
    {'label': 'Zoom', 'value': 'ZM'},
]

data_depth = 450
default_span = 270
app = MyDash('Simple Stocks', title="POC")


def stock_monitor_table(uid, ticker, title):
    graph_id = f'graph_{uid}'
    graph2_id = f'graph2_{uid}'
    ddown_id = f'dropdown_{uid}'
    submit_id = f'sub_{uid}'
    div_id = f'div_{uid}'
    x2_id = f'x2_{uid}'

    if isinstance(title, list):
        header = html.Td(
            dcc.Dropdown(
                id=ddown_id,
                options=title,
                value=ticker,
                clearable=False
            ), style={'width': '175px'}
        )
        # TODO: Rewrite it all using Ramda
        app.clientside_callback(
            """
            function innerGraph2Update(ticker, data, figure) {{
                // dcc.Graph puts the plotly graph in this child element
                let gDiv = document.querySelector("#{0} > div.js-plotly-plot")
            
                const days = data['days_ago']
                //console.log('figData', gDiv.data)
                //let trace = data[ticker]
                let trace = [
                {{ 
                    x: data[ticker].index.slice(-days),
                    y: R.map( x => {{ return x / 1000000 }},  data[ticker].Volume.slice(-days)),
                    name: 'Volume',  
                    type: 'bar',
                    line: {{ color: 'cyan' }},
                }},
                {{ 
                    x: data[ticker].index.slice(-days), 
                    y: data[ticker].Open.slice(-days),
                    name: 'Open',  
                    line: {{ color: 'purple' }},
                }},
                {{ 
                    x: data[ticker].index.slice(-days), 
                    y: data[ticker].Low.slice(-days),
                    line: {{ color: 'red' }},
                    name: 'Low',  
                }},
                {{ 
                    x: data[ticker].index.slice(-days), 
                    y: data[ticker].High.slice(-days),
                    name: 'High',  
                    line: {{ color: 'green' }},
                }},
                {{ 
                    x: data[ticker].index.slice(-days), 
                    y: R.zipWith( (x, y) => {{ return x - y }},  data[ticker].High.slice(-days), data[ticker].Low.slice(
                    -days) ),
                    name: 'High-Low',  
                    line: {{ color: 'yellow' }},
                }},
                ]


                if (gDiv) {{
                    // preserve visibility selections
                    for (var i=0;i<gDiv.data.length;i++) {{
                        if (gDiv.data[i]['visible']) {{
                            trace[i]['visible'] = gDiv.data[i]['visible'];
                        }}
                    }}

                    Plotly.react(
                       gDiv, 
                       trace , 
                       {{ 
                            //paper_bgcolor: '#7a7a7f',
                            yaxis: {{ automargin: true}},
                            xaxis: {{ visible: false}},
                            margin: {{ r: 1, l: 1, t: 1, b: 25 }}
                        }} 
                       )
                }}
                return figure
            }}
            """.format(graph2_id),
            Output(graph2_id, 'figure'),
            [Input(ddown_id, 'value'),
             Input('STOCK_DATA', 'data')],
            State(graph2_id, 'figure')
        )

        # TODO: Make this a range selection instead of a data slice
        app.clientside_callback(
            """
            function innerGraphUpdate(ticker, data) {{
                const days = data['days_ago']
                let trace = {{ 
                    x: data[ticker].index.slice(-days), 
                    y: data[ticker].Close.slice(-days),
                    name: ticker,  
                }}
                // dcc.Graph puts the plotly graph in this child element
                let gDiv = document.querySelector("#{0} > div.js-plotly-plot")
                if (gDiv) {{
                    Plotly.react(
                       gDiv, 
                       [trace], 
                       {{ 
                            //paper_bgcolor: '#7a7a7f',
                            yaxis: {{ automargin: true}},
                            xaxis: {{ visible: false}},
                            margin: {{ r: 1, l: 1, t: 1, b: 25 }}
                        }} 
                       )
                }}
                return
            }}
            """.format(graph_id),
            Output(div_id, 'children'),
            [Input(ddown_id, 'value'),
             Input('STOCK_DATA', 'data')],
        )
        app.clientside_callback(
            """
            function updateMainGraph(clicks, ticker) {{
                // dcc.Graph puts the plotly graph in this child element
                let gDiv = document.querySelector("#mg1 > div.js-plotly-plot")
                if (gDiv) {{
                    let oDiv = document.querySelector("#{0} > div.js-plotly-plot")
                    let g_data = oDiv.data
                    if (g_data.length == 0)
                      return '=>'
                    let trace = {{ name: g_data[0].name,  
                        x: g_data[0].x,  
                        y: g_data[0].y,  
                        layout: g_data[0]?.layout,
                    }}
                    Plotly.addTraces(gDiv, [trace])
                }}
                return '=>'
            }}
            """.format(graph_id),
            Output(submit_id, 'children'),
            [Input(submit_id, 'n_clicks')],
            [State(ddown_id, 'value')]
        )

        app.clientside_callback(
            """
            function graphx2(clicks, data) {{
                // dcc.Graph puts the plotly graph in this child element
                let oDiv = document.querySelector("#{0} > div.js-plotly-plot")
                if (oDiv) {{
                    let g_data = oDiv.data
                    if (g_data.length == 0)
                      return 'zero.len'
                    let trace = {{ name: g_data[0].name,  
                        x: g_data[0].x,  
                        y: R.map(x => x * 2, g_data[0].y), 
                        layout: g_data[0]?.layout,
                    }}
                    Plotly.react(oDiv, [trace],
                       {{ 
                            //paper_bgcolor: '#7a7a7f',
                            yaxis: {{automargin: true}},
                            xaxis: {{ visible: false}},
                            margin: {{ r: 1, l: 1, t: 1, b: 25 }}
                        }}
                    )
                }}
                return 'x2'
            }}
            """.format(graph_id),
            Output(x2_id, 'children'),
            [Input(x2_id, 'n_clicks')],
            [State("STOCK_DATA", 'data')]
        )
    else:
        # broken and dont fix it
        # just make a plain label if not a multi-choice
        header = html.Td(html.Div(title))

    return html.Table([
        html.Thead([
            html.Tr([
                header,
                html.Td(children=[
                    html.Button(id=x2_id, children='x2'),
                    html.Div(id=div_id, style={'display': 'none'}),
                    html.Button(id=submit_id, children='=>'),
                ],
                    style={"textAlign": "right"}),
            ]),
        ]),
        html.Tbody([
            html.Tr([
                html.Td(children=dcc.Graph(id=graph_id,
                                           figure=empty_graph(),
                                           config={'displayModeBar': False},
                                           # style={'height': '150px', 'width': '250px'}
                                           style={'height': '150px'}
                                           ),
                        colSpan=2),
            ]),
            html.Tr([
                html.Td(children=dcc.Graph(id=graph2_id,
                                           figure=empty_graph(),
                                           config={'displayModeBar': False},
                                           # style={'height': '150px', 'width': '250px'}
                                           style={'height': '150px'}
                                           ),
                        colSpan=2,
                        style={'backgroundColor': 'gray'}),
            ]),
        ]),
    ])


def populate_data_store(days):
    store_data = {'depth': abs(days), 'days_ago': default_span}
    for row in default_stock_list:
        ticker = row['value']
        # print("getting {t} {d} days".format(t=ticker, d=days))
        stock_text = get_stock_data(days, ticker)
        store_data[ticker] = {
            'index': stock_text.index,
            'High': stock_text.High,
            'Low': stock_text.Low,
            'Open': stock_text.Open,
            'Close': stock_text.Close,
            'Volume': stock_text.Volume,
        }
    return dcc.Store(
        id="STOCK_DATA",
        data=store_data
    )


app.data_store = populate_data_store(data_depth)

app.layout = html.Div([
    html.Div([
        html.Div([
            html.Div("Days Ago: "),
            html.Div(id='daysAgoLabel', children=default_span),
        ]),
        dcc.Slider(id='slider',
                   updatemode='drag',
                   value=(-default_span),
                   min=-data_depth,
                   max=-10,
                   step=10
                   ),
        app.data_store,
    ]),
    html.Table([
        html.Tbody([
            html.Tr([
                # left column
                html.Td(children=[
                    stock_monitor_table('1', "NFLX", default_stock_list),
                    stock_monitor_table('2', "TSLA", default_stock_list),
                    # stock_monitor_table('3', "ZM", default_stock_list),
                ]),
                # main graph on right
                html.Td(children=[
                    html.Div(id="instructions_top", children='Click & DblClick legend manages trace visibility',
                             style={'textAlign': 'right'}),
                    dcc.Graph(id='mg1',
                              figure=empty_graph(),
                              config={'displayModeBar': False},
                              ),
                    html.Div(id="popDiv", children=''),
                    html.Button(id='clearButton', children='Drop hidden traces', ),
                ], ),
            ]),
        ])
    ], style={'width': '100%'})
])

# drop deselected traces (i.e. visible in the legend only)
app.clientside_callback(
    """
    function innerClear(clicks, data) {
        let gDiv = document.querySelector("#mg1 > div.js-plotly-plot")
        if (! gDiv )
            return               
        if (gDiv.data.length == 0)
            return
        
        let selected = []
        for (var i=0; i<gDiv.data.length; i++) {
            const cell = gDiv.data[i] 
            if ( 'legendonly' == cell['visible'])
                selected.push(i)
        }
        
        if (selected.length > 0)
            Plotly.deleteTraces(gDiv, selected )
            
        return
    }
    """,
    Output('popDiv', 'children'),
    Input('clearButton', 'n_clicks')
)

# clientside call to update #days displayed
app.clientside_callback(
    """
    function innerDaysUpdate(data) {
        return data['days_ago'];
    }
    """,
    Output('daysAgoLabel', 'children'),
    Input('STOCK_DATA', 'data'),
)

app.clientside_callback(
    """
    function sliderStockMethod(days, data) {
        data['days_ago'] = Math.abs(days)
        return data;
    }
    """,
    Output('STOCK_DATA', 'data'),
    Input('slider', 'value'),
    State('STOCK_DATA', 'data'),
)

# # The serverside call that populates STOCK_DATA
# @app.callback(Output('STOCK_DATA', 'data'),
#               Input('slider', 'value'))
# def fill_data(days_ago):
#     return populate_data_store(days_ago).data

# quick non-debug run for external page generation
do_debug = True
if args.port == 8888:
    do_debug = False
    print("Forced Production Mode")

if __name__ == '__main__':
    app.run_server(debug=do_debug, port=args.port, threaded=False)
