if (!window.dash_clientside) {
    window.dash_clientside = {}
}
window.dash_clientside.clientside = {

    add_exp: function(a, b) {
        return window.R.add(a, b);
    },

    display: function (value) {
        console.log(" xxxxx value: " + value);
        return 'Client (js) says "' + value + '"';
    },

}
