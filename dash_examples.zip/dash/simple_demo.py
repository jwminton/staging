from pandas import read_pickle
from pandas_datareader import data as web
from os import path
from datetime import datetime
from datetime import timedelta
import dash
from dash.dependencies import Input, Output, State, ClientsideFunction
import dash_core_components as dcc
import dash_html_components as html

# Quick command arg parsing. If we run on port 8888, the app will
# switch off debug mode so that a non-debug version of the page can be easily
# downloaded and processed to be a standalone page (script locations are
# rewritten to be local and assumed to be production minified versions)
# TODO: move sed/rewrite rules into the page generation logic itself
# Maybe try a Flask alternative app routing magic trick?
import argparse

# start with '-p 8888' for non-debug mode
parser = argparse.ArgumentParser()
parser.add_argument('-p', '--port', type=int, default=8050)
args = parser.parse_args()

CACHE_DIR = 'dash_cache'
DATA_DEPTH = 30
STOCK_DATA = "STOCK_DATA"
GRAPH_ID = 'graph_1'
DROPDOWN_ID = 'dropdown_1'
DIV_ID = 'div_1'
POP_DIV = 'popDiv'


# Custom Dash implementation so that layout & dep info can be easily included
# in the generated page. The altered dash-renderer js will use this instead of
# going back to the dash server, as is required by default.
class MyDash(dash.Dash):
    # initial layout and dependency script element
    def layout_script_elements(self):
        return '''<script id="_dash-layout" type="application/json">{auto_layout}</script>
                <script id="_dash-dependencies" type="application/json">{auto_deps}</script>'''.format(
            auto_layout=self.serve_layout().response[0].decode("utf-8"),
            auto_deps=self.dependencies().response[0].decode("utf-8"))

    def getCss(self):
        return '''
<style>
* {
  box-sizing: border-box;
}
th, td {
  padding: 2px;
}
table {
  border: 1px solid black;
}
</style>'''

    # Called by Dash/Flask during startup for root page definition
    def interpolate_index(self, **kwargs):
        # TODO: see if Dash's Ramda can be exposed instead of doing this
        local_scripts = """<script src="/static/ramda.min.js"></script>"""

        return '''<!DOCTYPE html>
        <html>
            <head>
                {css}
                <title>Plotly/Dash Demo</title>
            </head>
            <body>   
             {app_entry}
                {config}
                {auto_layout}
                {local_scripts}
                {scripts}
                {renderer}
            </body>
        </html>'''.format(app_entry=kwargs.get('app_entry'),
                          auto_layout=self.layout_script_elements(),
                          config=kwargs.get('config'),
                          scripts=kwargs.get('scripts'),
                          local_scripts=local_scripts,
                          renderer=kwargs.get('renderer'),
                          css=self.getCss(),
                          )


# Normal stock data retrieval stuff from yahoo
def get_stock_data(days_ago, selected_value) -> object:
    if path.exists(CACHE_DIR):
        cache_file_name = f'{CACHE_DIR}/{selected_value}_{days_ago}.pkl'
        try:
            ret_val = read_pickle(cache_file_name)
            print("cache hit:", cache_file_name)
            return ret_val
        except IOError:
            print('cache miss: ', cache_file_name)

    print(f'Fetching {selected_value} data for {days_ago} days')
    ret_val = web.DataReader(
        selected_value,
        'yahoo',
        datetime.now() - timedelta(days=days_ago),  # days_ago is negative
        datetime.now()
    )

    if path.exists(CACHE_DIR):
        print(f'caching: {cache_file_name}')
        ret_val.to_pickle(cache_file_name)
    return ret_val


def empty_graph():
    return {
        'data': [],
        'layout': {
            # 'paper_bgcolor': '#7f7f7f',
            'showlegend': True,
            'margin': {'l': 15, 'r': 5, 't': 15, 'b': 20},
            'yaxis': {'automargin': True},
            'xaxis': {'automargin': True},
        }
    }


# precanned stock choices
default_stock_list = [
    # {'label': 'IBM', 'value': 'IBM'},
    {'label': 'Tesla', 'value': 'TSLA'},
    {'label': 'Zoom', 'value': 'ZM'},
    {'label': 'Netflix', 'value': 'NFLX'},
]

# TODO: better std deviation, weighted
ramda_operation_list = [
    {'label': 'Sum', 'value': 'sum'},
    {'label': 'Average', 'value': 'avg'},
    {'label': 'Median', 'value': 'median'},
    {'label': 'Min', 'value': 'min'},
    {'label': 'Max', 'value': 'max'},
    {'label': 'Cumulative Sum', 'value': 'csum'},
    {'label': 'std deviation', 'value': 'stdDev'},
]


def stock_monitor_table():
    operation_list = html.Td(
        dcc.Dropdown(
            id=DROPDOWN_ID,
            options=ramda_operation_list,
            clearable=True
        ), style={'width': '175px'}
    )
    return html.Table(
        children=[
            html.Thead([
                html.Tr([
                    operation_list,
                    html.Td(children=[
                        html.Div(id=DIV_ID),
                    ],
                        style={"textAlign": "right"}),
                ]),
            ]),
            html.Tbody([
                html.Tr([
                    html.Td(children=dcc.Graph(id=GRAPH_ID,
                                               figure=empty_graph(),
                                               # config={'displayModeBar': False},
                                               ),
                            colSpan=2),
                ]),
            ]),
        ],
        style={'width': '100%'},
    )


def populate_data_store(days=DATA_DEPTH):
    store_data = {'_depth': days}
    for row in default_stock_list:
        ticker_label = row['label']
        ticker = row['value']
        stock_df = get_stock_data(days, ticker)
        key = f'Q:{ticker}'
        store_data[key] = {
            'key': key,
            'symbol': ticker,
            'label': ticker_label,
            'index': stock_df.index,
            'High': stock_df.High,
            'Low': stock_df.Low,
            'Open': stock_df.Open,
            'Close': stock_df.Close,
            'Volume': stock_df.Volume,
        }

    return dcc.Store(
        id=STOCK_DATA,
        data=store_data
    )


app = MyDash('Simpler Stocks', title="POC")

app.data_store = populate_data_store()

app.layout = html.Div([
    html.Div([
        app.data_store,
        stock_monitor_table(),
        html.Div(id=POP_DIV, children=''),
    ]),
])

app.clientside_callback(
    """
    function innerStockUpdate2(data, fig) {{
        // dcc.Graph puts the plotly graph in this child element
        const gDiv = document.querySelector("#{graph_id} > div.js-plotly-plot")
        if (gDiv == null) {{
            console.log('empty gDiv')
            return ''
        }}

        const traceArray = []
        const stockKeys = R.compose(R.filter(R.prop('key')))(data)
        for (const key in stockKeys) {{
            const stock = data[key]
            if (stock.trace == null) {{
                stock.trace = {{
                    x: stock.index, 
                    y: stock.Close,
                    name: stock.label,  
                }}
            }}
            traceArray.push(stock.trace)
        }}

        var selectorOptions = {{
            buttons: [{{
                step: 'day',
                stepmode: 'backward',
                count: 1,
                label: '1d'
            }}, {{
                step: 'day',
                stepmode: 'backward',
                count: 7,
                label: '1wk'
            }}, {{
                step: 'all',
            }}],
        }};
        var layout = {{
            title: 'Time series',
            xaxis: {{
                rangeselector: selectorOptions,
                rangeslider: {{}}
            }},
            yaxis: {{
                fixedrange: true
            }},
            showlegend: true,
        }};
        data.layout = layout
        Plotly.react('{graph_id}', traceArray, layout);

        return '';
    }}
    """.format(graph_id=GRAPH_ID),
    Output(POP_DIV, 'children'),
    Input(STOCK_DATA, 'data'),
    State(GRAPH_ID, 'figure')
)

# TODO: Make this a range selection instead of a data slice
app.clientside_callback(
    """
    function aggregateFunctionSelection(commandId, data, fig) {{        
        // start from Object.values so it ends up being an array 
        // and not a generic js object.
        const dataArray = R.compose(
            R.map(R.prop('y')),
            R.map(R.prop('trace')),
            R.filter(R.prop('key')),
        )(Object.values(data))

        // can be undefined if traces have not been cached into 'data' elements
        if ( dataArray[0] == undefined )
            return fig

        const transposedData = R.transpose(dataArray)
        var trace = {{
               computed: 'true',
               x: data[Object.keys(data)[1]].index ,
               line: {{ color: 'purple' }},
               name: commandId
        }}

        var traceArray = [ trace ]

        switch (commandId) {{
            case 'sum':
                trace.y = R.map(R.sum)(transposedData)
                break
            case 'median':
                trace.y = R.map(R.median)(transposedData)
                break
            case 'avg':
                trace.name='average'
                trace.y = R.map(R.mean)(transposedData)
                break
            case 'min':
                trace.y = R.map(R.reduce(R.min, Infinity))(transposedData)
                break 
            case 'max':
                trace.y = R.map(R.reduce(R.max, -Infinity))(transposedData)
                break 
            case 'csum':
                var appender = (a, b) => [a + b, a + b];
                var cSumList = R.compose(
                      R.head,
                      R.tail,
                      R.mapAccum(appender, 0)
                );
                var cSumVal = R.compose(
                      R.head,
                      R.mapAccum(appender, 0)
                );
                trace.y = R.map(cSumList, R.map(cSumVal))(transposedData)
                trace.name = "Cumulative" 
                break
            case 'stdDev':
                const meanData = R.map(R.mean)(transposedData)
                const sumData = R.map(R.sum)(transposedData)
                trace.y = R.zipWith((a, b) => {{ return b - Math.abs(b - a) }}, meanData, sumData)
                trace.name = 'Dev.' 
                break
            default:
                // replace whole array with original traces
                traceArray = R.compose(
                    R.map(R.prop('trace')),
                    R.filter(R.prop('key')),
                )(Object.values(data))
        }}
        Plotly.react('{graph_id}', traceArray, data.layout);
        return fig
    }}
    """.format(graph_id=GRAPH_ID),
    Output(GRAPH_ID, "figure"),
    [Input(DROPDOWN_ID, 'value'),
     Input(STOCK_DATA, 'data'),
     ],
    State(GRAPH_ID, "figure")
)

# # The serverside call that populates STOCK_DATA
# @app.callback(Output('STOCK_DATA', 'data'),
#               Input('slider', 'value'))
# def fill_data(days_ago):
#     return populate_data_store(abs(days_ago)).data

# non-debug run mainly for external page generation
do_debug = True
if args.port == 8888:
    do_debug = False
    print("Forced Production Mode")

if __name__ == '__main__':
    app.run_server(debug=do_debug, port=args.port, threaded=False)
